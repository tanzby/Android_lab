package pub.tanzby.herodict;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.LinearSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView mRecycleView;
    RCAdapter     mAdapter;
    Integer current_item_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
 
        ArrayList<Hero>  heroList = Hero.getDataFromXMLSource(MainActivity.this,R.xml.test_hero);

        mRecycleView = (RecyclerView) findViewById(R.id.id_recyclerview);

         /*set RecyclerView*/
        mRecycleView.setLayoutManager(new LinearLayoutManager(
                this, LinearLayoutManager.HORIZONTAL, false));
        new LinearSnapHelper().attachToRecyclerView(mRecycleView);
        mRecycleView.smoothScrollToPosition(1);

        mRecycleView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {

                super.onScrolled(recyclerView, dx, dy);
                /*update current item id*/
                LinearLayoutManager layoutManager = (LinearLayoutManager) mRecycleView.getLayoutManager();
                View firstVisibleItem = mRecycleView.getChildAt(0);
                int firstItemPosition = layoutManager.findFirstVisibleItemPosition();
                int itemWidth = firstVisibleItem.getWidth();
                int firstItemBottom = layoutManager.getDecoratedRight(firstVisibleItem);
                current_item_id = px2dip(MainActivity.this,(firstItemPosition+1)*itemWidth-firstItemBottom);
            }
        });


        mAdapter = new RCAdapter(this, heroList );
        mAdapter.setOnItemClickLitener(
                new RCAdapter.OnItemClickLitener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        Toast.makeText(MainActivity.this,"短按",Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onItemLongClick(View view, final int position) {
                        Toast.makeText(MainActivity.this,"长按",Toast.LENGTH_SHORT).show();
                    }
                }
        );

        mRecycleView.setAdapter(mAdapter);

    }


    public static int px2dip(Context context, float pxValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (pxValue / scale + 0.5f);
    }


}
